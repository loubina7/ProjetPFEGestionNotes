package Acceuil;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import Connexion.connexion;




public class Acceuil_etudiant extends JFrame implements ActionListener{
	JLabel lab1,lab2;
	JComboBox jcb1,jcb2;
	JButton jb1,jb2,jb3;
	JTable tb;
	JScrollPane scrl,scrl2;
	Statement st;
	ResultSet rst;
	connexion cn=new connexion();
	String login;
	public Acceuil_etudiant(String l)
	
	{     this.setTitle("Acceuil_etudiant");
		  this.setSize(1300,650);
		  this.setLocationRelativeTo(null);
	      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      this.setResizable(false);
	      
	      this.login = l;
		  
	      JPanel p=new JPanel();
		     p.setLayout(null);
		     p.setBackground(new Color(160,160,200));
		     p.setSize(200,100);
		     
		     JLabel txt=new  JLabel(" Bienvenu "+login+" dans l'espace des �tudiants");
		     txt.setBounds(400,20,500,30); 
	         txt.setFont(new Font("Arial",Font.BOLD,22));
	         txt.setForeground(Color.red);
	         this.add(txt);
	         
	         lab1=new JLabel("RELEVE DES NOTES ");
	 		 lab1.setBounds(800,50,500,30);
	 		lab1.setForeground(Color.gray);
	 		 lab1.setFont(new Font("Arial",Font.BOLD,18));
	 		 p.add(lab1);
	 		//label1
	 		lab1=new JLabel("SEMESTRE :");
	 		lab1.setBounds(615,100,100,30);
	 		lab1.setFont(new Font("Arial",Font.BOLD,15));
	 		p.add(lab1);
	 		//combo1
	 		jcb1=new JComboBox();
	 		jcb1.addItem("S1");
	 		jcb1.addItem("S2");
	 		jcb1.addItem("S3");
	 		jcb1.addItem("S4");
	 		jcb1.setBounds(715,100,80,30);
	 		p.add(jcb1);
	 		//label2
	 		lab2=new JLabel("MODULE :");
	 		lab2.setBounds(810,100,80,30);
	 		lab2.setFont(new Font("Arial",Font.BOLD,15));
	 		p.add(lab2);
	 		//combo2
	 		jcb2=new JComboBox();
	 		String query="SELECT * FROM module where nom_semestre='"+jcb1.getSelectedItem().toString()+"'" ;
			
		    try{
		    	Statement st=cn.etablirconnection().createStatement();
		    	ResultSet rst=st.executeQuery(query);
				
		    	while(rst.next())
		    	    {
		    		  jcb2.addItem(rst.getString("nom_module"));
					    }
			
		         }
		    catch(SQLException ex){
			    JOptionPane.showMessageDialog(null,"Erreur de base de donn�es !");
			    //ex.printStackTrace();
		        }
	 		jcb2.setBounds(900,100,80,30);
	 		p.add(jcb2);
	 				
	 				jb1=new JButton("Recherche");
	 				jb1.setBounds(1030,100,100,30);
	 				jb1.setBackground(Color.orange);
	 				jb1.setForeground(Color.blue);
	 				jb1.addActionListener(this);
	 				p.add(jb1);
	 				
	 				//
	 				DefaultTableModel df=new DefaultTableModel();
	 				init();
	 				df.addColumn("NOM");
	    			df.addColumn("PRENOM");
	    			df.addColumn("MATIERE");
	    			df.addColumn("NOTE");
	    			df.addColumn("FILIERE");
	    			df.addColumn("SEMESTRE");
	 				tb.setModel(df);
	 				p.add(scrl);
	 				this.add(p);
	 		
	}
	private void init(){
		tb=new JTable();
		scrl=new JScrollPane();
		scrl.setViewportView(tb);
		scrl.setBounds(600,150,600,400);
		
	}
	      
		public static void main(String[] args) {
			
			Acceuil_etudiant fen=new Acceuil_etudiant("Brahim");
			fen.setVisible(true);
		}
       public void actionPerformed(ActionEvent e) {
    		// TODO Auto-generated method stub
    		if(e.getSource()==jb1){
    			String a;
    			a=jcb1.getSelectedItem().toString();
    			DefaultTableModel df=new DefaultTableModel();
    			df.addColumn("NOM");
    			df.addColumn("PRENOM");
    			df.addColumn("MATIERE");
    			df.addColumn("NOTE");
    			df.addColumn("FILIERE");
    			df.addColumn("SEMESTRE");
    			tb.setModel(df);
    			String qry="select * from note inner join etudiant on id_etudiant=note.idetudiant inner join matiere on note.idmatiere=matiere.idmat  where matricule='"+a+"'";
    			/*try{
    				st=cn.etablirconnection().createStatement();
    				rst=st.executeQuery(qry);
    				while(rst.next()){
    					df.addRow(new Object[]{
    							rst.getString("nom"),rst.getString("prenom"),rst.getString("controle"),rst.getString("examen")
    						,rst.getString("tp"),rst.getString("appelation")
    							
    					});
    					
    				}
    				
    			}
    			catch(SQLException ex){
    				JOptionPane.showMessageDialog(this,"INTROUVABLE",null,JOptionPane.ERROR_MESSAGE);
    			}*/
    			
    		}
    		
    	}


    	


	}

