package Acceuil;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.*;

import Connexion.connexion;




public class Acceuil_chef_de_deppartement  extends JFrame {
	
	String login;
	public Acceuil_chef_de_deppartement (String l)
	
	{     
		  this.setTitle("Acceuil_chef_de_deppartement");
		  this.setSize(900,700);
		  this.setLocationRelativeTo(null);
	      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      this.setResizable(false);
	      
	      this.login = l;
	      		  
	      JPanel p=new JPanel();
		     p.setLayout(null);
		     p.setBackground(new Color(160,160,200));
		     
		     JLabel txt=new  JLabel("Bienvenu dans l'espace de chef de deppartement");
		     txt.setBounds(270,10,550,30); p.add(txt);
	         txt.setFont(new Font("Arial",Font.BOLD,16));
	         txt.setBackground(Color.green);
	         txt.setForeground(Color.red);
	         
	         JLabel txt2=new  JLabel(login);
		     txt2.setBounds(10,10,550,30); p.add(txt);
	         txt2.setFont(new Font("Arial",Font.BOLD,16));
	         txt2.setBackground(Color.green);
	         txt2.setForeground(Color.black);
	         p.add(txt2);
	         
		     this.add(p);
	}
	      
		public static void main(String[] args) {
			
			Acceuil_chef_de_deppartement fen=new Acceuil_chef_de_deppartement("Brahim");
			fen.setVisible(true);
		}
	}
