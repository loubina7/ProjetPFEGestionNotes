
package Acceuil;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Connexion.connexion;
import Validation_cpt.Validation_cdd;
import Validation_cpt.Validation_etudiant;
import Validation_cpt.Validation_prof;




public class Acceui_admin  extends JFrame {
	
	String login;
	JButton jb1,jb2,jb3,jb4,jb5,jb1p,jb2p,jb1d,jb2d,jb1f,jb2f;
	JButton jb6,jb7;
	JTextField jtf8,jtf2,jtf3,jtf4,jtf5,jtf6,jtf7,jtf9,jtf2p,jtf3p,jtf4p,jtf5p,jtf2d,jtf3d,jtf4d,jtf5d,jtf2f,jtf3f,jtf4f,jtf5f,jtf6f;
	JTable tb;
	JScrollPane scrl;
	connexion cn=new connexion();
	JComboBox jcb;
	Statement st,stt;
	ResultSet rst;
	JLabel jp;
    int n;
	public Acceui_admin (String l)
	
	{     
		  this.setTitle("Acceuil_admin");
		  this.setSize(1200,700);
		  this.setLocation(170,60);
	      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      this.setResizable(false);
	      
	        this.login = l;
	      		  
	        JPanel pn=new JPanel();
			pn.setLayout(null);
			pn.setBackground(Color.black);
			//etudiant
			
			
			JLabel j1 = new JLabel();
			j1.setBounds(10,150,500,490);
			pn.add(j1);
			j1.setForeground(Color.white);
			j1.setVisible(false);
			JLabel lb1=new JLabel("ETUDIANT");
			lb1.setFont(new Font("Arial",Font.BOLD,17));
			lb1.setForeground(Color.white);
			lb1.setBounds(190,20,100,25);
			j1.add(lb1);
			
	 	JLabel lb2=new JLabel("Appog�e :");
		lb2.setFont(new Font("Arial",Font.BOLD,15));
		lb2.setForeground(Color.white);
		lb2.setBounds(100,60,100,25);
		j1.add(lb2);
		
		jtf2=new JTextField();
		jtf2.setBounds(200,60,190,25);
		j1.add(jtf2);
		jtf2.setEnabled(false);
		jtf2.setBackground(new Color(60,60,60));
		jtf2.setFont(new Font("Arial",Font.BOLD,15));
		
		
		// Nom
		JLabel lb3=new JLabel("Nom :");
		lb3.setFont(new Font("Arial",Font.BOLD,15));
		lb3.setBounds(100,100,100,25);
		lb3.setForeground(Color.white);
		j1.add(lb3);
		
	 	jtf3=new JTextField();
	 	jtf3.setBounds(200,100,190,25);
	 	j1.add(jtf3);
	 	jtf3.setEnabled(false);
		jtf3.setBackground(new Color(60,60,60));
		jtf3.setFont(new Font("Arial",Font.BOLD,15));;
	 	// Prenom
	 		JLabel lb4=new JLabel("Prenom :");
	 		lb4.setFont(new Font("Arial",Font.BOLD,15));
	 		lb4.setBounds(100,140,100,25);
	 		lb4.setForeground(Color.white);
	 		j1.add(lb4);
	 		
	 		jtf4=new JTextField();
	 		jtf4.setBounds(200,140,190,25);
	 		j1.add(jtf4);
	 		jtf4.setEnabled(false);
			jtf4.setBackground(new Color(60,60,60));
			jtf4.setFont(new Font("Arial",Font.BOLD,15));;
	 	// datNais
	 		JLabel lb5=new JLabel("N� le :");
	 		lb5.setFont(new Font("Arial",Font.BOLD,15));
	 		lb5.setBounds(100,180,150,30);
	 		lb5.setForeground(Color.white);
	 		j1.add(lb5);
	 				
	 		jtf5=new JTextField();
	 		jtf5.setBounds(200,180,190,25);
	 		j1.add(jtf5);
	 		jtf5.setEnabled(false);
			jtf5.setBackground(new Color(60,60,60));
			jtf5.setFont(new Font("Arial",Font.BOLD,15));;
	 	//email
	 		JLabel lb6=new JLabel("Email :");
	 		lb6.setFont(new Font("Arial",Font.BOLD,15));
	 		lb6.setBounds(100,220,100,30);
	 		lb6.setForeground(Color.white);
	 		j1.add(lb6);
	 		
	 		jtf6=new JTextField();
	 		jtf6.setBounds(200,220,190,25);
	 		j1.add(jtf6);
	 		jtf6.setEnabled(false);
			jtf6.setBackground(new Color(60,60,60));
			jtf6.setFont(new Font("Arial",Font.BOLD,15));;
	 		
	 	//filiere
	 		JLabel lb7=new JLabel("Filiere :");
	 		lb7.setFont(new Font("Arial",Font.BOLD,15));
	 		lb7.setBounds(100,260,100,30);
	 		lb7.setForeground(Color.white);
	 		j1.add(lb7);
	 		
	 		jtf7=new JTextField();
	 		jtf7.setBounds(200,260,190,25);
	 		j1.add(jtf7);
	 		jtf7.setEnabled(false);
			jtf7.setBackground(new Color(60,60,60));
			jtf7.setFont(new Font("Arial",Font.BOLD,15));;
	   //Ann�e
	 		JLabel lb8=new JLabel("Ann�e :");
	 		lb8.setFont(new Font("Arial",Font.BOLD,15));
	 		lb8.setBounds(100,300,100,30);
	 		lb8.setForeground(Color.white);
	 		j1.add(lb8);
	 		
	 		jtf8=new JTextField();
	 		jtf8.setBounds(200,300,190,25);
	 		j1.add(jtf8);
	 		jtf8.setEnabled(false);
			jtf8.setBackground(new Color(60,60,60));
			jtf8.setFont(new Font("Arial",Font.BOLD,15));;
	    //semestre
	 		JLabel lb9=new JLabel("Semestre :");
	 		lb9.setFont(new Font("Arial",Font.BOLD,15));
	 		lb9.setBounds(100,340,100,30);
	 		lb9.setForeground(Color.white);
	 		j1.add(lb9);
	 		
	 		jtf9=new JTextField();
	 		jtf9.setBounds(200,340,190,25);
	 		j1.add(jtf9);
	 		jtf9.setEnabled(false);
			jtf9.setBackground(new Color(60,60,60));
			jtf9.setFont(new Font("Arial",Font.BOLD,15));;
//Acceptation --- insertion des donn�es
jb1=new JButton("Accepter");
jb1.setBounds(255,410,100,25);
jb1.setBackground(Color.orange);
jb1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		j1.setVisible(false);
		String a=jcb.getSelectedItem().toString();
		String q="SELECT * from demande where NumeroDemande ="+a;
		String qr="SELECT * from demandeetudiant where NumeroDemande ='"+a+"'";
		String id_fili�re = null,nom = null,prenom = null,email = null,date = null,mdp = null, profil = null;
		try{
		    st=cn.etablirconnection().createStatement();
		    rst=st.executeQuery(q);    
		    while(rst.next())
	 	    {
		    	 nom = rst.getString("Nom");
			     prenom = rst.getString("Prenom");
			     email = rst.getString("Email");
			     email = email.replaceAll(" ", "");
			     date = rst.getString("DateNaissance");
			     mdp = rst.getString("MotDePasse");
			     profil = rst.getString("Profil");
			     String qry5 = "INSERT INTO users values('"+email+"','"+mdp+"','"+profil+"')";
		         st.executeUpdate(qry5);
            }
                  
		}
		catch(SQLException ex) {
			
		}
		try {
			st=cn.etablirconnection().createStatement();
		    rst=st.executeQuery(qr);
		    while(rst.next())
	 	    { 
		    	String filiere = rst.getString("filiere");
		    	filiere = filiere.replaceAll(" ", "");
		    	try {
		    		stt=cn.etablirconnection().createStatement();
		    	    ResultSet rs = stt.executeQuery("SELECT * FROM fili�re where nom_fili�re ='"+filiere+"'");
		        while(rs.next()) {
		          id_fili�re = rs.getString("id_fili�re");
		         }
		        }
		    	catch(SQLException ex){
					
				}
			     st.executeUpdate("INSERT INTO etudiant values('"+rst.getString("Appog�e")+"','"+email+"','1','"+rst.getString("annee")+"','"+rst.getString("semestre")+"','"+nom+"','"+prenom+"','"+date+"')");
            }
		}
		catch(SQLException ex){
			JOptionPane.showMessageDialog(null,"Compte Ajouter ");
		}
		try{
			String qr10="DELETE from demande where NumeroDemande='"+a+"'";
			 st=cn.etablirconnection().createStatement();
			 st.executeUpdate(qr10); 
			}
			catch(SQLException ex){
				
			}
	}
});
j1.add(jb1);
//Refus ---- delete les donn�es
jb2=new JButton("Refuser");
jb2.setBounds(140,410,100,25);
jb2.setBackground(Color.orange);
jb2.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		j1.setVisible(false);
		String a=jcb.getSelectedItem().toString();
		try{
		String qr="DELETE from demande where NumeroDemande='"+a+"'";
		 st=cn.etablirconnection().createStatement();
		 st.executeUpdate(qr);
		 JOptionPane.showMessageDialog(null,"Op�ration terminer");	 
		}
		catch(SQLException ex){
			
		}
	}
});
j1.add(jb2);


			
			
			//



      /// PROFFFFF
             JLabel j2 = new JLabel();
             j2.setBounds(10,150,500,490);
             pn.add(j2);
             j2.setForeground(Color.white);
             j2.setVisible(false);
	
             JLabel lb1p=new JLabel("PROFESSEUR");
				lb1p.setFont(new Font("Arial",Font.BOLD,17));
				lb1p.setBounds(180,20,160,25);
				lb1p.setForeground(Color.white);
				j2.add(lb1p);
				
		 	JLabel lb2p=new JLabel("Nom :");
			lb2p.setFont(new Font("Arial",Font.BOLD,15));
			lb2p.setBounds(100,120,100,25);
			lb2p.setForeground(Color.white);
			j2.add(lb2p);
			
			
			 jtf2p=new JTextField();
			jtf2p.setBounds(200,120,190,25);
			j2.add(jtf2p);
			jtf2p.setEnabled(false);
			jtf2p.setBackground(new Color(60,60,60));
			jtf2p.setFont(new Font("Arial",Font.BOLD,15));
			
			
			// Nom
			JLabel lb3p=new JLabel("Prenom :");
			lb3p.setFont(new Font("Arial",Font.BOLD,15));
			lb3p.setBounds(100,160,100,25);
			lb3p.setForeground(Color.white);
			j2.add(lb3p);
			
			 jtf3p=new JTextField();
		 	jtf3p.setBounds(200,160,190,25);
		 	j2.add(jtf3p);
		 	jtf3p.setEnabled(false);
			jtf3p.setBackground(new Color(60,60,60));
			jtf3p.setFont(new Font("Arial",Font.BOLD,15));;
		 	// Prenom
		 		JLabel lb4p=new JLabel("Email :");
		 		lb4p.setFont(new Font("Arial",Font.BOLD,15));
		 		lb4p.setBounds(100,200,100,25);
		 		lb4p.setForeground(Color.white);
		 		j2.add(lb4p);
		 		
		 		 jtf4p=new JTextField();
		 		jtf4p.setBounds(200,200,190,25);
		 		j2.add(jtf4p);
		 		jtf4p.setEnabled(false);
				jtf4p.setBackground(new Color(60,60,60));
				jtf4p.setFont(new Font("Arial",Font.BOLD,15));;
		 	// datNais
		 		JLabel lb5p=new JLabel("N� le :");
		 		lb5p.setFont(new Font("Arial",Font.BOLD,15));
		 		lb5p.setBounds(100,240,150,30);
		 		lb5p.setForeground(Color.white);
		 		j2.add(lb5p);
		 				
		 		 jtf5p=new JTextField();
		 		jtf5p.setBounds(200,240,190,25);
		 		j2.add(jtf5p);
		 		jtf5p.setEnabled(false);
				jtf5p.setBackground(new Color(60,60,60));
				jtf5p.setFont(new Font("Arial",Font.BOLD,15));;
	//Acceptation --- insertion des donn�es
	 jb1p=new JButton("Accepter");
	jb1p.setBounds(255,360,100,25);
	jb1p.setBackground(Color.orange);
	jb1p.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			j2.setVisible(false);
			String a=jcb.getSelectedItem().toString();
			String q="SELECT * from demande where NumeroDemande ="+a;
			String qr="SELECT * from prof";
			String id_fili�re = null,nom = null,prenom = null,email = null,date = null,mdp = null, profil = null;
			try{
			    st=cn.etablirconnection().createStatement();
			    rst=st.executeQuery(q);    
			    while(rst.next())
		 	    {
			    	 nom = rst.getString("Nom");
				     prenom = rst.getString("Prenom");
				     email = rst.getString("Email");
				     email = email.replaceAll(" ", "");
				     mdp = rst.getString("MotDePasse");
				     profil = rst.getString("Profil");
				     String qry5 = "INSERT INTO users values('"+email+"','"+mdp+"','"+profil+"')";
			         st.executeUpdate(qry5);
             }
                   
			}
			catch(SQLException ex) {
				
			}
			try {
				st=cn.etablirconnection().createStatement();
			    rst=st.executeQuery(qr);
			    while(rst.next())
		 	    { 
			    	n++;
             }
			     st.executeUpdate("INSERT INTO prof values('"+n+"','"+email+"','"+nom+"','"+prenom+"')");
			     JOptionPane.showMessageDialog(null,"Compte Ajouter ");
			}
			catch(SQLException ex){
				JOptionPane.showMessageDialog(null,"Erreur de base de donn�es");
			}
			try{
				String qr10="DELETE from demande where NumeroDemande='"+a+"'";
				 st=cn.etablirconnection().createStatement();
				 st.executeUpdate(qr10); 
				}
				catch(SQLException ex){
					
				}
		}
	});
	j2.add(jb1p);
	//Refus ---- delete les donn�es
	 jb2p=new JButton("Refuser");
	jb2p.setBounds(140,360,100,25);
	jb2p.setBackground(Color.orange);
	jb2p.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			j2.setVisible(false);
			String a=jcb.getSelectedItem().toString();
			try{
			String qr="DELETE from demande where NumeroDemande='"+a+"'";
			 st=cn.etablirconnection().createStatement();
			 st.executeUpdate(qr);
			 JOptionPane.showMessageDialog(null,"Op�ration terminer");	 
			}
			catch(SQLException ex){
				
			}
		}
	});
	j2.add(jb2p);
	
	
	
	
	///////////
	///CHef de deppartement :
	
	
	JLabel j3 = new JLabel();
    j3.setBounds(10,150,500,490);
    pn.add(j3);
    j3.setForeground(Color.white);
    j3.setVisible(false);
    
    JLabel lb1d=new JLabel("CHEF DE DEPPARTEMENT");
				lb1d.setFont(new Font("Arial",Font.BOLD,17));
				lb1d.setBounds(135,20,250,25);
				lb1d.setForeground(Color.white);
				j3.add(lb1d);
				
		 	JLabel lb2d=new JLabel("Nom :");
			lb2d.setFont(new Font("Arial",Font.BOLD,15));
			lb2d.setBounds(100,120,100,25);
			lb2d.setForeground(Color.white);
			j3.add(lb2d);
			
			jtf2d=new JTextField();
			jtf2d.setBounds(200,120,190,25);
			j3.add(jtf2d);
			jtf2d.setEnabled(false);
			jtf2d.setBackground(new Color(60,60,60));
			jtf2d.setFont(new Font("Arial",Font.BOLD,15));
			
			
			// Nom
			JLabel lb3d=new JLabel("Prenom :");
			lb3d.setFont(new Font("Arial",Font.BOLD,15));
			lb3d.setBounds(100,160,100,25);
			lb3d.setForeground(Color.white);
			j3.add(lb3d);
			
		 	jtf3d=new JTextField();
		 	jtf3d.setBounds(200,160,190,25);
		 	j3.add(jtf3d);
		 	jtf3d.setEnabled(false);
			jtf3d.setBackground(new Color(60,60,60));
			jtf3d.setFont(new Font("Arial",Font.BOLD,15));;
		 	// Prenom
		 		JLabel lb4d=new JLabel("Email :");
		 		lb4d.setFont(new Font("Arial",Font.BOLD,15));
		 		lb4d.setBounds(100,200,100,25);
		 		lb4d.setForeground(Color.white);
		 		j3.add(lb4d);
		 		
		 		jtf4d=new JTextField();
		 		jtf4d.setBounds(200,200,190,25);
		 		j3.add(jtf4d);
		 		jtf4d.setEnabled(false);
				jtf4d.setBackground(new Color(60,60,60));
				jtf4d.setFont(new Font("Arial",Font.BOLD,15));;
		 	// datNais
		 		JLabel lb5d=new JLabel("N� le :");
		 		lb5d.setFont(new Font("Arial",Font.BOLD,15));
		 		lb5d.setBounds(100,240,150,30);
		 		lb5d.setForeground(Color.white);
		 		j3.add(lb5d);
		 				
		 		jtf5d=new JTextField();
		 		jtf5d.setBounds(200,240,190,25);
		 		j3.add(jtf5d);
		 		jtf5d.setEnabled(false);
				jtf5d.setBackground(new Color(60,60,60));
				jtf5d.setFont(new Font("Arial",Font.BOLD,15));;
	//Acceptation --- insertion des donn�es
	jb1d=new JButton("Accepter");
	jb1d.setBounds(255,360,100,25);
	jb1d.setBackground(Color.orange);
	jb1d.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			dispose();
			String a=jcb.getSelectedItem().toString();
			String q="SELECT * from demande where NumeroDemande ="+a;
			String nom = null,prenom = null,email = null,date = null,mdp = null, profil = null;
			try {
				 st=cn.etablirconnection().createStatement();
				 st.executeUpdate("DELETE from users where profil = 'chefdd'");
			}
           catch(SQLException ex) {
           	JOptionPane.showMessageDialog(null,"Erreur");	
			}
			try{
			    st=cn.etablirconnection().createStatement();
			    rst=st.executeQuery(q); 
			    while(rst.next())
		 	    {
			    	 nom = rst.getString("Nom");
				     prenom = rst.getString("Prenom");
				     email = rst.getString("Email");
				     email = email.replaceAll(" ", "");
				     mdp = rst.getString("MotDePasse");
				     String qry5 = "INSERT INTO users values('"+email+"','"+mdp+"','chefdd')";
			         st.executeUpdate(qry5);
               }
			    JOptionPane.showMessageDialog(null,"Compte Ajouter");	
			}
			catch(SQLException ex) {
				 JOptionPane.showMessageDialog(null,"Compte Ajouter");		
			}
			try{
				String qr10="DELETE from demande where NumeroDemande='"+a+"'";
				 st=cn.etablirconnection().createStatement();
				 st.executeUpdate(qr10); 
				}
				catch(SQLException ex){
					
				}
		}
		
	});
	j3.add(jb1d);
	//Refus ---- delete les donn�es
	jb2d=new JButton("Refuser");
	jb2d.setBounds(140,360,100,25);
	jb2d.setBackground(Color.orange);
	jb2d.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			dispose();
			String a=jcb.getSelectedItem().toString();
			try{
			String qr="DELETE from demande where NumeroDemande='"+a+"'";
			 st=cn.etablirconnection().createStatement();
			 st.executeUpdate(qr);
			 JOptionPane.showMessageDialog(null,"Op�ration terminer");	 
			}
			catch(SQLException ex){
				
			}
		}
	});
	j3.add(jb2d);
	
	
	////////////////
	// CHEF de fili���re 
	
	JLabel j4 = new JLabel();
	j4.setBounds(10,150,500,490);
	pn.add(j4);
	j4.setForeground(Color.white);
	j4.setVisible(false);
    JLabel lb1f=new JLabel("CHEF DE FILIERE");
				lb1f.setFont(new Font("Arial",Font.BOLD,17));
				lb1f.setBounds(165,20,250,25);
				lb1f.setForeground(Color.white);
				j4.add(lb1f);
				// Nom	
		 	JLabel lb2f=new JLabel("Nom :");
			lb2f.setFont(new Font("Arial",Font.BOLD,15));
			lb2f.setBounds(100,120,100,25);
			lb2f.setForeground(Color.white);
			j4.add(lb2f);
			
			jtf2f=new JTextField();
			jtf2f.setBounds(200,120,190,25);
			j4.add(jtf2f);
			jtf2f.setEnabled(false);
			jtf2f.setBackground(new Color(60,60,60));
			jtf2f.setFont(new Font("Arial",Font.BOLD,15));
			
			
			// Prenom
			JLabel lb3f=new JLabel("Prenom :");
			lb3f.setFont(new Font("Arial",Font.BOLD,15));
			lb3f.setBounds(100,160,100,25);
			lb3f.setForeground(Color.white);
			j4.add(lb3f);
			
		 	jtf3f=new JTextField();
		 	jtf3f.setBounds(200,160,190,25);
		 	j4.add(jtf3f);
		 	jtf3f.setEnabled(false);
			jtf3f.setBackground(new Color(60,60,60));
			jtf3f.setFont(new Font("Arial",Font.BOLD,15));;
		 	//Email
		 		JLabel lb4f=new JLabel("Email :");
		 		lb4f.setFont(new Font("Arial",Font.BOLD,15));
		 		lb4f.setBounds(100,200,100,25);
		 		lb4f.setForeground(Color.white);
		 		j4.add(lb4f);
		 		
		 		jtf4f=new JTextField();
		 		jtf4f.setBounds(200,200,190,25);
		 		j4.add(jtf4f);
		 		jtf4f.setEnabled(false);
				jtf4f.setBackground(new Color(60,60,60));
				jtf4f.setFont(new Font("Arial",Font.BOLD,15));;
		 	// datNais
		 		JLabel lb5f=new JLabel("N� le :");
		 		lb5f.setFont(new Font("Arial",Font.BOLD,15));
		 		lb5f.setBounds(100,240,150,30);
		 		lb5f.setForeground(Color.white);
		 		j4.add(lb5f);
		 				
		 		jtf5f=new JTextField();
		 		jtf5f.setBounds(200,240,190,25);
		 		j4.add(jtf5f);
		 		jtf5f.setEnabled(false);
				jtf5f.setBackground(new Color(60,60,60));
				jtf5f.setFont(new Font("Arial",Font.BOLD,15));;
				
				// Fili�re
		 		JLabel lb6f=new JLabel("Fili�re :");
		 		lb6f.setFont(new Font("Arial",Font.BOLD,15));
		 		lb6f.setBounds(100,280,150,30);
		 		lb6f.setForeground(Color.white);
		 		j4.add(lb6f);
		 				
		 		jtf6f=new JTextField();
		 		jtf6f.setBounds(200,280,190,25);
		 		j4.add(jtf6f);
		 		jtf6f.setEnabled(false);
				jtf6f.setBackground(new Color(60,60,60));
				jtf6f.setFont(new Font("Arial",Font.BOLD,15));;
	//Acceptation --- insertion des donn�es
	jb1f=new JButton("Accepter");
	jb1f.setBounds(255,360,100,25);
	jb1f.setBackground(Color.orange);
	jb1f.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			j4.setVisible(false);
			String a=jcb.getSelectedItem().toString();
			String q="SELECT * from demande where NumeroDemande ="+a;
			String qr="SELECT * from chef_de_fili�re";
			String nom = null,prenom = null,email = null,date = null,mdp = null, profil = null;
			try{
			    st=cn.etablirconnection().createStatement();
			    rst=st.executeQuery(q);    
			    while(rst.next())
		 	    {
			    	 nom = rst.getString("Nom");
				     prenom = rst.getString("Prenom");
				     email = rst.getString("Email");
				     email = email.replaceAll(" ", "");
				     mdp = rst.getString("MotDePasse");
				     profil = rst.getString("Profil");
				     String qry5 = "INSERT INTO users values('"+email+"','"+mdp+"','"+profil+"')";
			         st.executeUpdate(qry5);
             }
                   
			}
			catch(SQLException ex) {
				
			}
			try {
				st=cn.etablirconnection().createStatement();
			    rst=st.executeQuery(qr);
			    while(rst.next())
		 	    { 
			    	n++;
             }
			     st.executeUpdate("INSERT INTO chef_de_fili�re values('"+n+"','"+email+"','"+nom+"','"+prenom+"')");
			     JOptionPane.showMessageDialog(null,"Compte Ajouter ");
			}
			catch(SQLException ex){
				JOptionPane.showMessageDialog(null,"Erreur de base de donn�es");
			}
			try{
				String qr10="DELETE from demande where NumeroDemande='"+a+"'";
				 st=cn.etablirconnection().createStatement();
				 st.executeUpdate(qr10); 
				}
				catch(SQLException ex){
					
				}
		}
		
	});
	j4.add(jb1f);
	//Refus ---- delete les donn�es
	jb2f=new JButton("Refuser");
	jb2f.setBounds(140,360,100,25);
	jb2f.setBackground(Color.orange);
	jb2f.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			j4.setVisible(false);
			String a=jcb.getSelectedItem().toString();
			try{
			String qr="DELETE from demande where NumeroDemande='"+a+"'";
			 st=cn.etablirconnection().createStatement();
			 st.executeUpdate(qr);
			 JOptionPane.showMessageDialog(null,"Op�ration terminer");	 
			}
			catch(SQLException ex){
				
			}
		}
	});
	j4.add(jb2f);
	
	       //L'interface de l admin :
		     JLabel txt=new  JLabel("LA GESTION DES INSCRIPTIONS");
		     txt.setBounds(420,10,550,30); pn.add(txt);
	         txt.setFont(new Font("Algerian",Font.BOLD,23));
	         txt.setForeground(new Color(255,100,60));
	         
	         JLabel txt2=new  JLabel("LA LISTE DES DEMANDES");
		     txt2.setBounds(700,10,550,110); pn.add(txt2);
	         txt2.setFont(new Font("Arial",Font.BOLD,16));
	         txt2.setForeground(Color.white);
	         
	         JLabel txt3=new  JLabel("LA DEMANDE D'INSCRIPTION");
		     txt3.setBounds(140,10,550,110); pn.add(txt3);
	         txt3.setFont(new Font("Arial",Font.BOLD,16));
	         txt3.setForeground(Color.white);
	         
	         DefaultTableModel df=new DefaultTableModel();
				init();
				df.addColumn("N� demande");
				df.addColumn("Nom");
				df.addColumn("Prenom");
				df.addColumn("Date Naissance");
				df.addColumn("Email");
				df.addColumn("Profil");
				tb.setModel(df);
				pn.add(scrl);
				String query="SELECT * FROM demande";
			    try{
			    	Statement st=cn.etablirconnection().createStatement();
			    	ResultSet rst=st.executeQuery(query);
			    	while(rst.next())
			    	    {
			     		 df.addRow(new Object[]{ rst.getString("NumeroDemande"), rst.getString("Nom"), rst.getString("Prenom"),rst.getString("DateNaissance"),rst.getString("Email"),rst.getString("Profil")  });
					    }
			         }
			    catch(SQLException ex){
				    JOptionPane.showMessageDialog(null,"Erreur de base de donn�es !");
				    //ex.printStackTrace();
			        }
			
				this.add(pn);
				JLabel txt4=new  JLabel("N� Demande :");
			     txt4.setBounds(10,100,150,25); pn.add(txt4);
		         txt4.setBackground(Color.green);
		         txt4.setForeground(Color.white);
				//les listes 
				jcb=new JComboBox();
				
			    try{
			    	Statement st=cn.etablirconnection().createStatement();
			    	ResultSet rst=st.executeQuery(query);
					
			    	while(rst.next())
			    	    {
			    		  jcb.addItem(rst.getString("NumeroDemande"));
 					    }
				
			         }
			    catch(SQLException ex){
				    JOptionPane.showMessageDialog(null,"Erreur de base de donn�es !");
				    //ex.printStackTrace();
			        }
				jcb.setBounds(150,100,100,25);
				pn.add(jcb);
				//les boutons
				jb1=new JButton("Actualiser");
				jb1.setBounds(950,51,100,25);
				jb1.setBackground(Color.orange);
				n=1;
				jb1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
						String q="SELECT * from demande"; 
						try{
							 Statement st=cn.etablirconnection().createStatement();
							 Statement stt=cn.etablirconnection().createStatement();
						     ResultSet rst=st.executeQuery(q);
						
						 while(rst.next())
					 	    {
							 String ne = Integer.toString(n);;
							 stt.executeUpdate("UPDATE demande set NumeroDemande = '"+ne+"' where NumeroDemande='"+rst.getString("NumeroDemande")+"'"); 
							 n=n+1;
					 	    }
					}catch(SQLException ex){
						//JOptionPane.showMessageDialog(null,"Erreur de base de donn�es !");
					}
						Acceui_admin  fen=new  Acceui_admin ("Brahim");
					    fen.setVisible(true);
						
					}});
				pn.add(jb1);
				//
				jb5=new JButton("Chercher");
				jb5.setBounds(290,100,100,25);
				jb5.setBackground(Color.orange);
				jb5.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String a=jcb.getSelectedItem().toString();
						
						//savoir le profil 
						String b = null;
						String q = "SELECT * FROM demande where NumeroDemande ='"+a+"'";
						try{
					    	Statement st=cn.etablirconnection().createStatement();
					    	ResultSet rst=st.executeQuery(q);
							
					    	while(rst.next())
					    	    {
					    		  b=rst.getString("Profil");
		 					    }
						       
					    	
					         }
					    catch(SQLException ex){
						    JOptionPane.showMessageDialog(null,"Erreur de base de donn�es !");
						    //ex.printStackTrace();
					        }
						b = b.replaceAll(" ", "");
						switch(b) {
						
						
						
						case "etudiant" :
							j1.setVisible(true);
							j2.setVisible(false);
							j3.setVisible(false);
							j4.setVisible(false);
							// Remplissage de formulaire par les donn�es d'etudiant choisi .
							
							String qry = "SELECT * FROM demandeetudiant where NumeroDemande	='"+a+"'";
							String qry2 = "SELECT * FROM demande where NumeroDemande='"+a+"'";
							try{
								 st=cn.etablirconnection().createStatement(); 
								 String appoge = null,fili�re = null,annee = null,semestre = null,nom = null, prenom = null ,email = null;
								 String date = null;
								 rst=st.executeQuery(qry);
								 while(rst.next())
								    {
								  appoge = "  "+rst.getString("Appog�e");
								  fili�re =  "  "+rst.getString("filiere");
								  annee =  "  "+rst.getString("annee");
								  semestre =  "  "+rst.getString("semestre");
								  
								    }
								 rst=st.executeQuery(qry2);
								 while(rst.next())
							 	    {
								  nom =  "  "+rst.getString("Nom");
								  prenom =  "  "+rst.getString("Prenom");
								  email =  "  "+rst.getString("Email");
								  date ="  "+rst.getString("DateNaissance").toString();
							 	    }
								 jtf2.setText(appoge);
								 jtf3.setText(nom);
								 jtf4.setText(prenom);
								 jtf5.setText(date);
								 jtf6.setText(email);
								 jtf7.setText(fili�re);
								 jtf8.setText(annee);
								 jtf9.setText(semestre);
							}
							catch(SQLException ex){
								 JOptionPane.showMessageDialog(null,"Erreur de base des donn�es !");
								 ex.printStackTrace();
								
							}
						break;
						
						
						
						case "prof" : 
							j1.setVisible(false);
							j2.setVisible(true);
							j3.setVisible(false);
							j4.setVisible(false);
							// Remplissage de formulaire par les donn�es d'etudiant choisi .
							 qry2 = "SELECT * FROM demande where NumeroDemande='"+a+"'";
							try{
								 st=cn.etablirconnection().createStatement(); 
								 String nom = null, prenom = null ,email = null;
								 String date = null;
								 rst=st.executeQuery(qry2);
								 while(rst.next())
							 	    {
								  nom =  "  "+rst.getString("Nom");
								  prenom =  "  "+rst.getString("Prenom");
								  email =  "  "+rst.getString("Email");
								  date ="  "+rst.getString("DateNaissance").toString();
							 	    }
								 jtf2p.setText(nom);
								 jtf3p.setText(prenom);
								 jtf4p.setText(email);
								 jtf5p.setText(date);
							}
							catch(SQLException ex){
								 JOptionPane.showMessageDialog(null,"Erreur de base des donn�es !");
								 ex.printStackTrace();
								
							}
						break;
						
						
						
						case "chefdf" :
							    j1.setVisible(false);
						        j2.setVisible(false);
						        j3.setVisible(false);
						        j4.setVisible(true);
						        
						     // Remplissage de formulaire par les donn�es d'etudiant choisi .
								
								 qry = "SELECT * FROM demandecheffiliere where NumeroDemande	='"+a+"'";
								 qry2 = "SELECT * FROM demande where NumeroDemande='"+a+"'";
								try{
									 st=cn.etablirconnection().createStatement(); 
									 String appoge = null,fili�re = null,annee = null,semestre = null,nom = null, prenom = null ,email = null;
									 String date = null;
									 rst=st.executeQuery(qry);
									 while(rst.next())
									    {
									  
									  fili�re =  "  "+rst.getString("filiere");
									  
									  
									    }
									 rst=st.executeQuery(qry2);
									 while(rst.next())
								 	    {
									  nom =  "  "+rst.getString("Nom");
									  prenom =  "  "+rst.getString("Prenom");
									  email =  "  "+rst.getString("Email");
									  date ="  "+rst.getString("DateNaissance").toString();
								 	    }
									
									 jtf2f.setText(nom);
									 jtf3f.setText(prenom);
									 jtf5f.setText(date);
									 jtf4f.setText(email);
									 jtf6f.setText(fili�re);
									
								}
								catch(SQLException ex){
									 JOptionPane.showMessageDialog(null,"Erreur de base des donn�es !");
									 ex.printStackTrace();
									
								}
						        
						break;
						
						
						case "chefdd" : 
							j1.setVisible(false);
							j2.setVisible(false);
							j3.setVisible(true);
							j4.setVisible(false);
							  // Remplissage de formulaire par les donn�es d'etudiant choisi .
							 qry2 = "SELECT * FROM demande where NumeroDemande='"+a+"'";
							try{
								 st=cn.etablirconnection().createStatement(); 
								 String nom = null, prenom = null ,email = null;
								 String date = null;
								 rst=st.executeQuery(qry2);
								 while(rst.next())
							 	    {
								  nom =  "  "+rst.getString("Nom");
								  prenom =  "  "+rst.getString("Prenom");
								  email =  "  "+rst.getString("Email");
								  date ="  "+rst.getString("DateNaissance").toString();
							 	    }
								 jtf2d.setText(nom);
								 jtf3d.setText(prenom);
								 jtf4d.setText(email);
								 jtf5d.setText(date);
							}
							catch(SQLException ex){
								 JOptionPane.showMessageDialog(null,"Erreur de base des donn�es !");
								 ex.printStackTrace();
								
							}
						break;
						
						
						
						}
									
				
				}});
				pn.add(jb5);	
				//
				
	}
	private void init(){
		tb=new JTable();
		scrl=new JScrollPane();
		scrl.setViewportView(tb);
		scrl.setBounds(520,90,660,550);  
		} 
		public static void main(String[] args) {
			
			 Acceui_admin  fen=new  Acceui_admin ("Brahim");
			 fen.setVisible(true);
		}
		
	}

	
		
	

