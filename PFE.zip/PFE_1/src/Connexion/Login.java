package Connexion;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.swing.*;

import Acceuil.*;



public class Login extends JFrame {
	
	JTextField txtlog;
	JPasswordField txtpwd;
	JButton con,ann,chm,cc;
	Statement st;
	ResultSet rt;
	connexion kk=new connexion();
	JCheckBox amd = new JCheckBox("afficher mot de passe");
	ImageIcon bkgd;
	public Login()
	
	{       
		     this.setTitle("Login_page");
		     this.setSize(600,400);
		     this.setLocationRelativeTo(null);
	         this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	         this.setResizable(false);
	         
		  
	         JPanel p=new JPanel();
		     p.setLayout(null);
		     p.setBackground(new Color(160,160,200));	        

		     bkgd = new ImageIcon("./arr.jpg");
		     JLabel jl =  new JLabel(bkgd);
		     jl.setBounds(0,0,600,400);
		     this.add(jl);
		     
		     
		     
		     txtlog=new JTextField();
		     txtpwd=new JPasswordField();
		     
		     JLabel txt=new  JLabel("Bienvenu dans l'application de Gestion passage des �tudiants");
		   
	         JLabel lblog=new JLabel("Login :");	      
	         JLabel lbpwd=new JLabel("Mot de passe :");
	         
	         
	         con=new JButton("Connexion");
	         ann=new JButton("Annuler");
	         
	               
	         txt.setBounds(15,20,550,30); jl.add(txt);
	         txt.setFont(new Font("Algerian",Font.BOLD,16));
	         txt.setBackground(Color.green);
	         txt.setForeground(new Color(255,100,60));
	         
	         JLabel txt3 = new JLabel("ESTO");
	         txt3.setBounds(260,50,550,30); jl.add(txt3);
	         txt3.setFont(new Font("Algerian",Font.BOLD,22));
	         txt3.setBackground(Color.green);
	         txt3.setForeground(new Color(255,100,60));
	       
	         lblog.setBounds(120,103,150,23);  jl.add(lblog);
	         lblog.setForeground(Color.white);
	         txtlog.setBounds(250,100,200,27); jl.add(txtlog);
	      
	         lbpwd.setBounds(120,145,170,23); jl.add(lbpwd);
	         lbpwd.setForeground(Color.white);
	         txtpwd.setBounds(250,140,200,27); jl.add(txtpwd);
	         amd.setBounds(250,165,200,27);jl.add(amd);
	         amd.setBorderPainted(false);
	         amd.setForeground(Color.white);
		     amd.setOpaque(false);
	         
	         con.setBounds(177,220,110,25); jl.add(con);
	         con.setBackground(Color.orange);
	         ann.setBounds(303,220,110,25); jl.add(ann);
	         ann.setBackground(Color.orange);
	      
	         chm=new JButton("Changer mot de passe ?");
	         chm.setBounds(400,337,172,23);
		     chm.setBackground(new Color(160,160,200));
		     chm.setBorderPainted(false);
		     chm.setOpaque(false);
		     chm.setForeground(Color.blue);
		     jl.add(chm);
		     
		     cc=new JButton("Cr�er un compte ?");
	         cc.setBounds(7,337,140,23);
		     cc.setBackground(new Color(0,0,0));
		     cc.setBorder(null);
		     cc.setBorderPainted(false);
		     cc.setOpaque(false);
		     cc.setForeground(Color.blue);
		     jl.add(cc);
	      
	      
	 //les �v�nements pour la connection
	      
	         con.addActionListener(new ActionListener() {
			
			 @Override
			 public void actionPerformed(ActionEvent e) {
				    
				    String c,p;
				    c=txtlog.getText(); 
				    p=txtpwd.getText();
				
				    String query="SELECT * FROM users WHERE login='"+c+"' and mot_de_passe='"+p+"'"; 
				
				
			 try {
					st=kk.etablirconnection().createStatement();
					rt=st.executeQuery(query);
					
					if(rt.next()) {
						
						if(c.equalsIgnoreCase(rt.getString("login")) && p.equalsIgnoreCase(rt.getString("mot_de_passe")))
						{
							String profil = rt.getString("profil");
							profil = profil.replaceAll(" ", "");
							switch(profil) {
							case "chefdf" :
							                  Acceuil_chef_de_fili�re f_c=new Acceuil_chef_de_fili�re(c);
							                  f_c.setVisible(true); 
							                  dispose(); 
							                  break; 
							case "etudiant" : 
							                  
							                  Acceuil_etudiant f_e=new Acceuil_etudiant(c);
					                          f_e.setVisible(true);
					                          dispose();
							                  break;
							case "prof" :
								              Acceuil_prof f_p=new Acceuil_prof(c);
	                                          f_p.setVisible(true);
	                                          dispose();
			                                  break;
							case "chefdd" :
								              Acceuil_chef_de_deppartement f_d=new Acceuil_chef_de_deppartement(c);
	                                          f_d.setVisible(true);
	                                          dispose();
			                                  break;
							case "admin" :
								  dispose();
					              Acceui_admin f_a=new Acceui_admin(c);
                                  f_a.setVisible(true);
                                
                                break;
							}
							
							
						  }
						  
						
					     }
					 
					else {
						    if((c.equals("")) || (p.equals(""))){
						    JOptionPane.showMessageDialog(null, "login ou mot de passe vide. R�essayer !  ");
					     }
					else {
						    JOptionPane.showMessageDialog(null, "Login ou mot de passe incorrect. R�essayer !  ");
					     }
				  }
					
				} catch (SQLException ex) {
					
					
					 ex.printStackTrace();
				}			
				
			}
			
			
		}
	      );
	      
	      
	      
	      //evenements pour la fermeture "close"
	      
	      ann.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
	      
	      //evenements pour changer mot de passe  
	     
	      chm.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					ChangePass cp=new ChangePass();
					cp.setVisible(true);
					dispose();
					
				}
			});
	      
	    //evenmenet afficher mot de passe 
		    amd.addActionListener(new ActionListener() {
				
				public void actionPerformed(ActionEvent e) {      
					if (amd.isSelected()) {
						txtpwd.setEchoChar((char) 0);
				}
					
	         else 
	        	txtpwd.setEchoChar('*');
	        
				}}
		
		    );
		    p.add(jl);
	     this.setContentPane(p);
		   
	   }
         
		public static void main(String[] args) {
			
			Login fen=new Login();
			fen.setVisible(true);
		}
		
		
		public static void ecrire(String fich, String msg) {
			try {
				File f = new File(fich);
				FileWriter fw = new FileWriter(fich);
				PrintWriter pw = new PrintWriter(fw);
				pw.println(msg);
				pw.close();
			}
			catch(IOException ex) {
				ex.printStackTrace();
			}
		}

	}

	


