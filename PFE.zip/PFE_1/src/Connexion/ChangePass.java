package Connexion;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import java.sql.*;

public class ChangePass extends JFrame {
	JLabel lb1,lb2,lb3,lb4;
	JTextField tf1;
	JPasswordField tf2,tf3,tf4;
	JButton jb,jb1;
	
	Statement st,st1;
	ResultSet rst;
	connexion cn=new connexion();
	public ChangePass(){
		this.setTitle("changer_mot_de_passe");
		this.setSize(570,320);
		this.setLocationRelativeTo(null);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		pn.setBackground(new Color(160,160,200));
		add(pn);
		
		
		lb1=new JLabel("Ancien Login :");
		lb1.setBounds(90,30,150,23);
		pn.add(lb1);
		
		tf1=new JTextField();
		tf1.setBounds(240,30,200,23);
		pn.add(tf1);
		//
		lb2=new JLabel("Ancien password :");
		lb2.setBounds(90,65,150,23);
		pn.add(lb2);
		
		tf2=new JPasswordField();
		tf2.setBounds(240,65,200,23);
		pn.add(tf2);
		//
		lb3=new JLabel("Nouveau password :");
		lb3.setBounds(90,120,150,23);
		pn.add(lb3);
		
		tf3=new JPasswordField ();
		tf3.setBounds(240,120,200,23);
		pn.add(tf3);
		//
		lb4=new JLabel("Confirmer password :");
		lb4.setBounds(90,160,150,23);
		pn.add(lb4);
		
		tf4=new JPasswordField();
		tf4.setBounds(240,160,200,23);
		pn.add(tf4);
		//jbutton
		jb=new JButton("Changer");
		jb.setBounds(140,220,130,23);
		jb.setBackground(Color.orange);
		jb.setForeground(Color.black);
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(e.getSource()==jb){
					String a,b,c,d;
					a=tf1.getText();
					b=tf2.getText();
					c=tf3.getText();
					d=tf4.getText();
					String query="SELECT * FROM users WHERE login='"+a+"' and mot_de_passe='"+b+"'"; 
					try{
						st=cn.etablirconnection().createStatement();
						rst=st.executeQuery(query);
						
						if(JOptionPane.showConfirmDialog(null,"Voulez vous changer le mot de passe?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
		                 if(rst.next()) {
		                	   if( (c.equals("")) || !(c.equals(d))) {
		                		       JOptionPane.showMessageDialog(null,"Modification impossible!");
								}								
							   else{
								   if(a.equalsIgnoreCase(rst.getString("login")) && b.equalsIgnoreCase(rst.getString("mot_de_passe")))
									{
										st.executeUpdate("update users set mot_de_passe='"+c+"' where login='"+a+"'");
									    dispose();
									    Login cp=new Login();
									    cp.setVisible(true);
									    JOptionPane.showMessageDialog(null,"Modification reussie!");
								     }
								   
									else {
										JOptionPane.showMessageDialog(null,"Modification impossible!");
									}
								    
							       }
							
						}
		                 else {
								JOptionPane.showMessageDialog(null,"Login ou mot de passe incorrect. R�essayer !");
							}
					}}
					catch(SQLException ex){
						System.out.println("erreur de base de donn�es !");
					}
					
					
				}
				
			}
		});
		jb1=new JButton("Annuler");
		jb1.setBounds(290,220,130,23);
		jb1.setBackground(Color.orange);
		jb1.setForeground(Color.black);
		jb1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				Login cp=new Login();
			    cp.setVisible(true);
			}
		});
		pn.add(jb);
		pn.add(jb1);
		
	}
	public static void main(String[] args){
		ChangePass chg = new ChangePass();
		chg.setVisible(true);
		
	}
	public  String log() {
		return tf1.getText();
	}
}
