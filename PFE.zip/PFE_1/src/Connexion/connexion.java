package Connexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class connexion {
	
	Connection con; 
	public connexion()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost/esto","root","");
			
			System.out.println("connection �tablie");
		
		} catch (Exception e) {
			
		
			System.out.println("Base de donnee introuvable");
		}
	}
	public Connection etablirconnection() {
		return con;
	}
	//savoir l'acc�s � la connection
	public static void main(String[] args) {
		
		connexion p=new connexion();
	
		System.out.println(p.etablirconnection());
	}
	
	}
	

